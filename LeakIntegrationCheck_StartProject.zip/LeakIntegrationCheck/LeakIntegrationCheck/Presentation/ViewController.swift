//
//  ViewController.swift
//  LeakIntegrationCheck
//
//  Created by BangNguyen on 8/12/18.
//  Copyright © 2018 BangNguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

}

