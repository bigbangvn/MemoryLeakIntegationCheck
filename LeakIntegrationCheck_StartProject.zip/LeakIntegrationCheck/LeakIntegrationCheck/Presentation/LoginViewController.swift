//
//  LoginViewController.swift
//  LeakIntegrationCheck
//
//  Created by BangNguyen on 8/12/18.
//  Copyright © 2018 BangNguyen. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loginBtn.layer.borderWidth = 1
        loginBtn.layer.cornerRadius = 4
        loginBtn.layer.borderColor = UIColor.brown.cgColor
    }

    @IBAction func didTapLogout(_ sender: Any) {
        AppDelegate.shared.switchToHomeScreen()
    }
}
