//
//  HomeViewController.swift
//  LeakIntegrationCheck
//
//  Created by BangNguyen on 8/12/18.
//  Copyright © 2018 BangNguyen. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var logoutBtn: UIButton!
    var managerHome: HomeManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        logoutBtn.layer.borderWidth = 1
        logoutBtn.layer.cornerRadius = 4
        logoutBtn.layer.borderColor = UIColor.brown.cgColor
        
        managerHome = HomeManager()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        /*
        managerHome.requestHomeInfo { _ in
            print("managerHome finish request")
        }
        */
    }

    @IBAction func didTapLogout(_ sender: Any) {
        AppDelegate.shared.switchToLoginScreen()
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        type(of: self).instanceCount += 1
        print("\(String(describing: self)) \(#function)")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static var instanceCount = 0
    
    deinit {
        type(of: self).instanceCount -= 1
        print("\(String(describing: self)) \(#function)")
    }
}
