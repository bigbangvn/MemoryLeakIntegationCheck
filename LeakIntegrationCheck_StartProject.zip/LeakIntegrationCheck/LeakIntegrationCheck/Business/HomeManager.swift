//
//  HomeManager.swift
//  LeakIntegrationCheck
//
//  Created by BangNguyen on 9/12/18.
//  Copyright © 2018 BangNguyen. All rights reserved.
//

import Foundation

final class HomeManager {
    func requestHomeInfo(_ completion: @escaping (_ response: MyEntity) -> ()) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            
            //Intentionally hold strongself here
            //This affects the delay time in your Leak-test
            self.processData()
            completion(MyEntity())
        }
    }
    
    private func processData() {
        print("\(String(describing: self)) \(#function)")
    }
    
#if ENABLE_LEAK_CHECK
    init() {
        type(of: self).instanceCount += 1
        print("\(String(describing: self)) \(#function)")
    }
    
    static var instanceCount = 0
    
    deinit {
        type(of: self).instanceCount -= 1
        print("\(String(describing: self)) \(#function)")
    }
#endif
}
