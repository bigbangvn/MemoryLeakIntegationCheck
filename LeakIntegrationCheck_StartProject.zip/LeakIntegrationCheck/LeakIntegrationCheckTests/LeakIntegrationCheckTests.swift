//
//  LeakIntegrationCheckTests.swift
//  LeakIntegrationCheckTests
//
//  Created by BangNguyen on 8/12/18.
//  Copyright © 2018 BangNguyen. All rights reserved.
//

import XCTest
@testable import LeakIntegrationCheck
import Nimble

class LeakIntegrationCheckTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
        
        //XCTAssert(noLeakHappen(), "Leak detected")
    }
    
    private func delayAndFlushTasks(_ sec: TimeInterval) {
#if true
        RunLoop.current.run(until: Date().addingTimeInterval(sec))
#else
        usleep(useconds_t(sec * Double(USEC_PER_SEC)))
#endif
    }
    
    func noLeakHappen() -> Bool {
        return HomeViewController.instanceCount == 0
        && HomeManager.instanceCount == 0
    }
    
    func testLeakAfterLogout() {
        
        delayAndFlushTasks(1.0)
        
        AppDelegate.shared.switchToHomeScreen()
        
        delayAndFlushTasks(1.0)
        
        AppDelegate.shared.switchToLoginScreen()
        
        //This delay is related to things that hold strong ref to your objects, such as UIView animation, Dispatch async/after hold strong ref,...
        //Eg: you can take a look at HomeManager.swift. So here it's only ok (have stable test result) if use delay > 4 sec
        delayAndFlushTasks(0)
        
        //Check for leaking
        
        //Failed 1
        XCTAssert(noLeakHappen(), "Leak detected")
    }
}
